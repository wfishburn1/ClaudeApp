package com.example.claudeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.claudeapp.ui.theme.ClaudeAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClaudeAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ClaudeAppTheme {
        Greeting("Android")
    }
}

// Models
data class Feature(
    val featureID: String,
    val title: String,
    val description: String,
    val category: String?,
    val priority: String,
    val status: String,
    val voteCount: Int,
    val createdAt: String,
    val createdBy: String,
    val createdByProfileImage: String?,
    var userVoted: Boolean = false
)

data class User(
    val userID: String,
    val email: String,
    val displayName: String,
    val firebaseUID: String,
    val profileImageURL: String?
)

data class ApiResponse<T>(
    val success: Boolean,
    val data: T?,
    val error: String?
)

// API Service Interface
interface FeatureVotingApi {
    @GET("features")
    suspend fun getFeatures(
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 10,
        @Query("category") category: String? = null,
        @Query("sortBy") sortBy: String = "votes"
    ): Response<FeatureListResponse>

    @GET("features/{id}")
    suspend fun getFeature(@Path("id") featureId: String): Response<FeatureResponse>

    @POST("features")
    suspend fun createFeature(@Body feature: CreateFeatureRequest): Response<CreateFeatureResponse>

    @POST("features/{id}/vote")
    suspend fun voteFeature(@Path("id") featureId: String): Response<VoteResponse>

    @DELETE("features/{id}/vote")
    suspend fun removeVote(@Path("id") featureId: String): Response<VoteResponse>

    @POST("users/sync")
    suspend fun syncUser(@Body user: SyncUserRequest): Response<SyncUserResponse>

    @GET("users/votes")
    suspend fun getUserVotes(): Response<UserVotesResponse>
}

// API Response Models
data class FeatureListResponse(val features: List<Feature>)
data class FeatureResponse(val feature: Feature)
data class CreateFeatureRequest(val title: String, val description: String, val category: String?, val priority: String?)
data class CreateFeatureResponse(val success: Boolean, val featureId: String)
data class VoteResponse(val success: Boolean, val voteCount: Int)
data class SyncUserRequest(val displayName: String, val email: String, val profileImageURL: String?)
data class SyncUserResponse(val success: Boolean, val userId: String)
data class UserVotesResponse(val votes: List<UserVote>)
data class UserVote(val featureID: String, val voteType: String, val createdAt: String, val featureTitle: String)

// Repository
class FeatureVotingRepository {
    private val api: FeatureVotingApi

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://us-central1-your-project-id.cloudfunctions.net/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(createOkHttpClient())
            .build()

        api = retrofit.create(FeatureVotingApi::class.java)
    }

    private fun createOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor { chain ->
                val token = FirebaseAuth.getInstance().currentUser?.getIdToken(false)?.result?.token
                val request = if (token != null) {
                    chain.request().newBuilder()
                        .addHeader("Authorization", "Bearer $token")
                        .build()
                } else {
                    chain.request()
                }
                chain.proceed(request)
            }
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .build()
    }

    suspend fun getFeatures(page: Int = 1, category: String? = null, sortBy: String = "votes"): List<Feature> {
        val response = api.getFeatures(page, category = category, sortBy = sortBy)
        return if (response.isSuccessful) {
            response.body()?.features ?: emptyList()
        } else {
            throw Exception("Failed to fetch features")
        }
    }

    suspend fun createFeature(title: String, description: String, category: String?, priority: String?): String {
        val response = api.createFeature(CreateFeatureRequest(title, description, category, priority))
        return if (response.isSuccessful && response.body()?.success == true) {
            response.body()!!.featureId
        } else {
            throw Exception("Failed to create feature")
        }
    }

    suspend fun voteFeature(featureId: String): Int {
        val response = api.voteFeature(featureId)
        return if (response.isSuccessful && response.body()?.success == true) {
            response.body()!!.voteCount
        } else {
            throw Exception("Failed to vote")
        }
    }

    suspend fun removeVote(featureId: String): Int {
        val response = api.removeVote(featureId)
        return if (response.isSuccessful && response.body()?.success == true) {
            response.body()!!.voteCount
        } else {
            throw Exception("Failed to remove vote")
        }
    }

    suspend fun syncUser(displayName: String, email: String, profileImageURL: String?): String {
        val response = api.syncUser(SyncUserRequest(displayName, email, profileImageURL))
        return if (response.isSuccessful && response.body()?.success == true) {
            response.body()!!.userId
        } else {
            throw Exception("Failed to sync user")
        }
    }

    suspend fun getUserVotes(): List<String> {
        val response = api.getUserVotes()
        return if (response.isSuccessful) {
            response.body()?.votes?.map { it.featureID } ?: emptyList()
        } else {
            emptyList()