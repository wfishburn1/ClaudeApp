//Firebase Cloud Functions for Feature Voting System
// npm install firebase-functions firebase-admin cors express

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const cors = require('cors');
const express = require('express');
const sql = require('mssql');

admin.initializeApp();

// SQL Server configuration
const sqlConfig = {
    user: functions.config().sqlserver.user,
    password: functions.config().sqlserver.password,
    database: 'FeatureVotingSystem',
    server: functions.config().sqlserver.server,
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true, // for Azure
        trustServerCertificate: false
    }
};

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

// Middleware to verify Firebase auth token
const verifyToken = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split('Bearer ')[1];
        if (!token) {
            return res.status(401).json({ error: 'No token provided' });
        }
        
        const decodedToken = await admin.auth().verifyIdToken(token);
        req.user = decodedToken;
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Invalid token' });
    }
};

// Database connection helper
const connectDB = async () => {
    try {
        const pool = await sql.connect(sqlConfig);
        return pool;
    } catch (error) {
        console.error('Database connection error:', error);
        throw error;
    }
};

// USERS ENDPOINTS

// Sync user from Firebase Auth to SQL Server
app.post('/api/users/sync', verifyToken, async (req, res) => {
    try {
        const pool = await connectDB();
        const { displayName, email, profileImageURL } = req.body;
        
        const result = await pool.request()
            .input('firebaseUID', sql.NVarChar, req.user.uid)
            .input('email', sql.NVarChar, email || req.user.email)
            .input('displayName', sql.NVarChar, displayName || req.user.name)
            .input('profileImageURL', sql.NVarChar, profileImageURL || req.user.picture)
            .query(`
                MERGE Users AS target
                USING (VALUES (@firebaseUID, @email, @displayName, @profileImageURL)) AS source (FirebaseUID, Email, DisplayName, ProfileImageURL)
                ON target.FirebaseUID = source.FirebaseUID
                WHEN MATCHED THEN
                    UPDATE SET DisplayName = source.DisplayName, ProfileImageURL = source.ProfileImageURL, UpdatedAt = GETDATE()
                WHEN NOT MATCHED THEN
                    INSERT (FirebaseUID, Email, DisplayName, ProfileImageURL)
                    VALUES (source.FirebaseUID, source.Email, source.DisplayName, source.ProfileImageURL);
                    
                SELECT UserID FROM Users WHERE FirebaseUID = @firebaseUID;
            `);
        
        res.json({ success: true, userId: result.recordset[0]?.UserID });
    } catch (error) {
        console.error('Error syncing user:', error);
        res.status(500).json({ error: 'Failed to sync user' });
    }
});

// FEATURES ENDPOINTS

// Get all features with pagination
app.get('/api/features', async (req, res) => {
    try {
        const pool = await connectDB();
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const category = req.query.category;
        const sortBy = req.query.sortBy || 'votes'; // votes, recent, oldest
        
        let orderBy = 'f.VoteCount DESC, f.CreatedAt DESC';
        if (sortBy === 'recent') orderBy = 'f.CreatedAt DESC';
        if (sortBy === 'oldest') orderBy = 'f.CreatedAt ASC';
        
        const offset = (page - 1) * limit;
        
        const request = pool.request()
            .input('limit', sql.Int, limit)
            .input('offset', sql.Int, offset);
            
        let query = `
            SELECT f.FeatureID, f.Title, f.Description, f.Category, f.Priority, f.Status,
                   f.VoteCount, f.CreatedAt, f.UpdatedAt,
                   u.DisplayName as CreatedBy, u.ProfileImageURL as CreatedByProfileImage
            FROM Features f
            INNER JOIN Users u ON f.CreatedByUserID = u.UserID
            WHERE f.IsActive = 1
        `;
        
        if (category) {
            query += ' AND f.Category = @category';
            request.input('category', sql.NVarChar, category);
        }
        
        query += ` ORDER BY ${orderBy} OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`;
        
        const result = await request.query(query);
        res.json({ features: result.recordset });
    } catch (error) {
        console.error('Error fetching features:', error);
        res.status(500).json({ error: 'Failed to fetch features' });
    }
});

// Get single feature by ID
app.get('/api/features/:id', async (req, res) => {
    try {
        const pool = await connectDB();
        const result = await pool.request()
            .input('featureId', sql.UniqueIdentifier, req.params.id)
            .query(`
                SELECT f.FeatureID, f.Title, f.Description, f.Category, f.Priority, f.Status,
                       f.VoteCount, f.CreatedAt, f.UpdatedAt,
                       u.DisplayName as CreatedBy, u.ProfileImageURL as CreatedByProfileImage
                FROM Features f
                INNER JOIN Users u ON f.CreatedByUserID = u.UserID
                WHERE f.FeatureID = @featureId AND f.IsActive = 1
            `);
        
        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'Feature not found' });
        }
        
        res.json({ feature: result.recordset[0] });
    } catch (error) {
        console.error('Error fetching feature:', error);
        res.status(500).json({ error: 'Failed to fetch feature' });
    }
});

// Create new feature
app.post('/api/features', verifyToken, async (req, res) => {
    try {
        const pool = await connectDB();
        const { title, description, category, priority } = req.body;
        
        // Get user ID from Firebase UID
        const userResult = await pool.request()
            .input('firebaseUID', sql.NVarChar, req.user.uid)
            .query('SELECT UserID FROM Users WHERE FirebaseUID = @firebaseUID');
            
        if (userResult.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const userId = userResult.recordset[0].UserID;
        
        const result = await pool.request()
            .input('title', sql.NVarChar, title)
            .input('description', sql.NVarChar, description)
            .input('category', sql.NVarChar, category || null)
            .input('priority', sql.NVarChar, priority || 'Medium')
            .input('createdByUserID', sql.UniqueIdentifier, userId)
            .query(`
                INSERT INTO Features (Title, Description, Category, Priority, CreatedByUserID)
                OUTPUT INSERTED.FeatureID
                VALUES (@title, @description, @category, @priority, @createdByUserID)
            `);
        
        res.json({ success: true, featureId: result.recordset[0].FeatureID });
    } catch (error) {
        console.error('Error creating feature:', error);
        res.status(500).json({ error: 'Failed to create feature' });
    }
});

// VOTING ENDPOINTS

// Vote on a feature
app.post('/api/features/:id/vote', verifyToken, async (req, res) => {
    try {
        const pool = await connectDB();
        const featureId = req.params.id;
        
        // Get user ID from Firebase UID
        const userResult = await pool.request()
            .input('firebaseUID', sql.NVarChar, req.user.uid)
            .query('SELECT UserID FROM Users WHERE FirebaseUID = @firebaseUID');
            
        if (userResult.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const userId = userResult.recordset[0].UserID;
        
        // Check if user already voted
        const existingVote = await pool.request()
            .input('featureId', sql.UniqueIdentifier, featureId)
            .input('userId', sql.UniqueIdentifier, userId)
            .query('SELECT VoteID FROM Votes WHERE FeatureID = @featureId AND UserID = @userId');
            
        if (existingVote.recordset.length > 0) {
            return res.status(400).json({ error: 'User already voted for this feature' });
        }
        
        // Add vote
        await pool.request()
            .input('featureId', sql.UniqueIdentifier, featureId)
            .input('userId', sql.UniqueIdentifier, userId)
            .input('voteType', sql.NVarChar, 'upvote')
            .query('INSERT INTO Votes (FeatureID, UserID, VoteType) VALUES (@featureId, @userId, @voteType)');
        
        // Get updated vote count
        const voteCountResult = await pool.request()
            .input('featureId', sql.UniqueIdentifier, featureId)
            .query('SELECT VoteCount FROM Features WHERE FeatureID = @featureId');
            
        res.json({ 
            success: true, 
            voteCount: voteCountResult.recordset[0]?.VoteCount || 0 
        });
    } catch (error) {
        console.error('Error voting:', error);
        res.status(500).json({ error: 'Failed to vote' });
    }
});

// Remove vote from a feature
app.delete('/api/features/:id/vote', verifyToken, async (req, res) => {
    try {
        const pool = await connectDB();
        const featureId = req.params.id;
        
        // Get user ID from Firebase UID
        const userResult = await pool.request()
            .input('firebaseUID', sql.NVarChar, req.user.uid)
            .query('SELECT UserID FROM Users WHERE FirebaseUID = @firebaseUID');
            
        if (userResult.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const userId = userResult.recordset[0].UserID;
        
        // Remove vote
        const result = await pool.request()
            .input('featureId', sql.UniqueIdentifier, featureId)
            .input('userId', sql.UniqueIdentifier, userId)
            .query('DELETE FROM Votes WHERE FeatureID = @featureId AND UserID = @userId');
            
        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Vote not found' });
        }
        
        // Get updated vote count
        const voteCountResult = await pool.request()
            .input('featureId', sql.UniqueIdentifier, featureId)
            .query('SELECT VoteCount FROM Features WHERE FeatureID = @featureId');
            
        res.json({ 
            success: true, 
            voteCount: voteCountResult.recordset[0]?.VoteCount || 0 
        });
    } catch (error) {
        console.error('Error removing vote:', error);
        res.status(500).json({ error: 'Failed to remove vote' });
    }
});

// Get user's votes
app.get('/api/users/votes', verifyToken, async (req, res) => {
    try {
        const pool = await connectDB();
        
        // Get user ID from Firebase UID
        const userResult = await pool.request()
            .input('firebaseUID', sql.NVarChar, req.user.uid)
            .query('SELECT UserID FROM Users WHERE FirebaseUID = @firebaseUID');
            
        if (userResult.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const userId = userResult.recordset[0].UserID;
        
        const result = await pool.request()
            .input('userId', sql.UniqueIdentifier, userId)
            .query(`
                SELECT v.FeatureID, v.VoteType, v.CreatedAt,
                       f.Title as FeatureTitle
                FROM Votes v
                INNER JOIN Features f ON v.FeatureID = f.FeatureID
                WHERE v.UserID = @userId
                ORDER BY v.CreatedAt DESC
            `);
        
        res.json({ votes: result.recordset });
    } catch (error) {
        console.error('Error fetching user votes:', error);
        res.status(500).json({ error: 'Failed to fetch user votes' });
    }
});

// ANALYTICS ENDPOINTS

// Get voting statistics
app.get('/api/analytics/stats', async (req, res) => {
    try {
        const pool = await connectDB();
        
        const result = await pool.request().query(`
            SELECT 
                (SELECT COUNT(*) FROM Features WHERE IsActive = 1) as TotalFeatures,
                (SELECT COUNT(*) FROM Votes) as TotalVotes,
                (SELECT COUNT(*) FROM Users WHERE IsActive = 1) as TotalUsers,
                (SELECT TOP 1 Category FROM Features WHERE IsActive = 1 GROUP BY Category ORDER BY COUNT(*) DESC) as MostPopularCategory
        `);
        
        res.json({ stats: result.recordset[0] });
    } catch (error) {
        console.error('Error fetching stats:', error);
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
});

// Export the API
exports.api = functions.region('us-central1').https.onRequest(app);